#####################################
#splitting regular de imagenes
#toni monleon 1-4-2019
#######################################
#list.images<- list.files("D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test",pattern = ".jpg")
#list.images<- list.files("C:/Users/Toni/Downloads/plastic/train",pattern = ".jpg")
#list.images<- list.files("C:/Users/Toni/Downloads",pattern = ".jpg")
#dir("../..", pattern = "^[a-lr]", full.names = TRUE, ignore.case = TRUE)
#list.images[2]

# imagen original #################################################
#setwd("C:/Users/Toni/Downloads/plastic/train")
#library(EBImage)
#list.images<- list.files("C:/Users/Toni/Downloads/plastic/train",pattern = ".jpg")
#list.images<- list.files("C:/Users/Toni/Downloads",pattern = ".jpg")
#setwd("C:/Users/Toni/Downloads")
#name.image <- list.images[1]
#img = readImage(name.image)
#representar imagen
#display(img)


#########################splitting image algorithm ##################################
#########################splitting algorithm ########################################
#########################splitting algorithm ########################################{

#example
#dir.imag<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
#dir.imag.final<- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
#image.splitting.algorithm(dir.imag, dir.imag.final, n.div=5)


#function:
image.splitting.algorithm <- function(dir.imag, dir.imag.final, n.div=5){

   library(EBImage)
   list.images<- list.files(dir.imag, pattern = ".JPG|.jpg|.png" )
   #list.images<- list.files("C:/Users/Toni/Downloads/plastic/train",pattern = ".jpg")
   #list.images<- list.files("C:/Users/Toni/Downloads",pattern = ".jpg")
   #para todas las imagenes
   #direcciono donde salvare los trozos de imagenes
   #setwd("C:/Users/Toni/Downloads")
   #setwd("C:/Users/Toni/Downloads/plastic/train")
   setwd(dir.imag.final)
   n.imagen<-0
   #bucle for
   for(k in 1:length(list.images)){
     #para cada imagen
     #k<-1
     name.image <- list.images[k] #jpg
     img = readImage(paste(dir.imag, "/", name.image,sep = ""))
     n.imagen <- n.imagen + 1
     ######3 splitting de la imagen ####################################

     #selecciono un trozo de la imagen al azar? o lo hago selectivamente.
     h<-dim(img)[1]
     w<-dim(img)[2]
     n.div <- n.div
     h.d <- floor(h/n.div)
     w.d <- floor(w/n.div)
     #h.inici<-1
     #w.inici<-1
     n.subimagen<- 0
     x<-seq(1,h, h.d-1)
     y<-seq(1,w, w.d-1)
     for(i in 1:n.div ){
       for(j in 1:n.div){
         #i<-1
         #j<-1
         #imagenes
         #h.final<- h.d*i
         #w.final<- w.d*j
         #h.inici:h.final,w.inici:w.final
         #if(h.final>dim(img)[1]){h.final<-dim(img)[1]}
         #if(w.final>dim(img)[2]){w.final<-dim(img)[2]}
         #if(w.inici == w.final){w.inici<-1}
         #if(h.inici == h.final){w.inici<-1}
         #if(w.inici> w.final){ w.inici<-w.final }
         #numero de sub-imagen
         n.subimagen <- n.subimagen + 1

         #print(i)
         #print(j)
         #print("hfinal")
         #print(h.final)
         #print("winici")
         #print(w.inici)
         #print("wfinal")
         #print(w.final)

         #seccionar la imagen en un trozo
         img.new <- img[x[i]:x[i+1],y[j]:y[j+1],]
         #dim(img)
         #display(img[h.inici:h.final,w.inici:h.final,])

         #display la imagen
         display(img.new, method="raster")

         #text(x = 20, y = 20, label = cat("Image", i,",", j, sep =""), adj = c(0,1), col = "orange", cex = 2)
         grepl("plastic_", name.image)
         fitxtxt<-"other_"
         if(grepl("sin_", name.image)==T){fitxtxt<-"sin_" }
         if(grepl("plastic_", name.image)==T){fitxtxt<-"plastic_" }
         filename = paste(fitxtxt,n.subimagen,"_c_",i,"_w",j,"si",n.imagen,".jpg", sep = "")

         #save image con dev(print)
         dev.print(jpeg, filename = filename , width = dim(img)[1], height = dim(img)[2])

         #jpeg(filename = filename , width = dim(img)[1], height = dim(img)[2])
         #dev.off()
         #savePlot(filename,type="jpg")
         #inicializo
         #w.inici<-w.final

         #print(paste("subimagen: ",i,",",j, sep = ""))

       }

       #inicializo
       #h.inici<-h.final

     }

   }




}

